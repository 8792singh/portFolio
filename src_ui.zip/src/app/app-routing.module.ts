import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './component/login/login.component';
import { RegisterationsComponent } from './component/registerations/registerations.component';
import { SportscontrollerComponent } from './component/sportscontroller/sportscontroller.component';
import { RouteGuardGuard } from './route-guard.guard';

const routes: Routes = [
  {path:'',component:LoginComponent},
  {path:'signup',component:RegisterationsComponent},
  {path:'login',component:LoginComponent},
  {path:'sports',component:SportscontrollerComponent, canActivate:[RouteGuardGuard]},
  {path:'login/sports',component:SportscontrollerComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
