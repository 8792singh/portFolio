export interface Userdetail {
    userName: string;
    password: string;
    email: string;
    phoneNumber: string;
}
