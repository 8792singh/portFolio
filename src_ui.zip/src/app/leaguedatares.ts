import { Leaguedata } from "./leaguedata";

export interface Leaguedatares {
    leagues: Leaguedata[];
}
