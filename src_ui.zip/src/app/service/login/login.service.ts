import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from 'src/app/user';
import { AuthResponse } from 'src/app/auth-response';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private apiUrl = 'http://localhost:9000/api/users';

  constructor(private http: HttpClient) {}

  authenticateUser(currentuser: User):Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/authenticate`, currentuser);
  }
  
}
