import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Favoriteleague } from 'src/app/favoriteleague';
import { League } from 'src/app/league';
import { Leaguedatares } from 'src/app/leaguedatares';

@Injectable({
  providedIn: 'root'
})
export class LeagueService {

  private apiUrl = 'http://localhost:9001/api/sports'; 

  constructor(private http: HttpClient) {}

  getLeagues(): Observable<Leaguedatares> {
    return this.http.get<Leaguedatares>(`${this.apiUrl}/`);
  }

  addFavLeague(favoriteLeague: Favoriteleague): Observable<string> { 
    return this.http.post<string>(`${this.apiUrl}/addFavLeague`, favoriteLeague); 
  }

  deleteFavLeague(userId: string, leagueId: string): Observable<string> {
    return this.http.delete<string>(`${this.apiUrl}/removeFavLeague/${userId}/${leagueId}`);
  }
}
