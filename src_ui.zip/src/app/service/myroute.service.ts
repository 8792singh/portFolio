import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class MyrouteService {

  constructor(private routeserve : Router,private locaobj : Location) { }

  openLogin()
  {
    this.routeserve.navigate(['login']);
  }

  goBack()
  {
    this.locaobj.back();
  }
  goForward()
  {
    this.locaobj.forward();
  }
}

