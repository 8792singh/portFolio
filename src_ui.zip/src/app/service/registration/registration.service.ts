import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Userdetail } from 'src/app/userdetail';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  constructor(private http: HttpClient) { }

  private apiUrl = 'http://localhost:9000/api/users/registerUser';

  register(userdetail: Userdetail) {
    console.log("From Service" + userdetail.password);
    return this.http.post(this.apiUrl, userdetail);
  }
}

