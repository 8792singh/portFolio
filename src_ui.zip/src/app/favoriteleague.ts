import { League } from "./league";

export interface Favoriteleague {
    userName: string;
    userId: string;
    leagueEntities: League[];
}
  