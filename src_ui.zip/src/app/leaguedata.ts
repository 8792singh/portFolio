export interface Leaguedata {
    idLeague: string;
    strLeague: string;
    strSport: string;
    strLeagueAlternate: string;
}
