import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SportscontrollerComponent } from './sportscontroller.component';

describe('SportscontrollerComponent', () => {
  let component: SportscontrollerComponent;
  let fixture: ComponentFixture<SportscontrollerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SportscontrollerComponent]
    });
    fixture = TestBed.createComponent(SportscontrollerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
