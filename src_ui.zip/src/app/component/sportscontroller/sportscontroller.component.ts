import { Component, OnInit } from '@angular/core';
import { Favoriteleague } from 'src/app/favoriteleague';
import { Leaguedatares } from 'src/app/leaguedatares';
import { LeagueService } from 'src/app/service/league/league.service';


@Component({
  selector: 'app-sports',
  templateUrl: './sportscontroller.component.html',
  styleUrls: ['./sportscontroller.component.css']
})
export class SportscontrollerComponent implements OnInit{

  //leaguedatares: Leaguedatares[] = [];
   leaguedatares: Leaguedatares = { leagues: [] };
  newFavLeague: Favoriteleague = { userName: '', userId: '', leagueEntities: [] }; 

  constructor(private leagueService: LeagueService) {
   
   }

  ngOnInit() {
    this.loadLeagues();
  }

  // loadLeagues() {
  //   this.leagueService.getLeagues().subscribe({
  //     next: (Leaguedatares) => {
  //       this.leaguedatares = this.leaguedatares;
        
  //     },
  //     error: (error: any) => {
  //       console.error('Error occurred while fetching leagues:', error);
  //     }
  //   });
  // }
  loadLeagues() {
    this.leagueService.getLeagues().subscribe({
      next: (data: Leaguedatares) => {
        this.leaguedatares = data; // Assign the retrieved data to leaguedatares
      },
      error: (error: any) => {
        console.error('Error occurred while fetching leagues:', error);
      }
    });
  }
  

 addFavLeague() {
    this.leagueService.addFavLeague(this.newFavLeague).subscribe(() => {
      this.newFavLeague = { userName: '', userId: '', leagueEntities: [] };
      this.loadLeagues();
    },
    error => {
      console.error('Error occurred while adding favorite league:', error);
    });
  }

  deleteFavLeague(userId: string, leagueId: string) {
    this.leagueService.deleteFavLeague(userId, leagueId).subscribe(() => {
      this.loadLeagues();
    },
    error => {
      console.error('Error occurred while deleting favorite league:', error);
    });
  }
}