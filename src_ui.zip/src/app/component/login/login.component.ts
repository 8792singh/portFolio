// import { Component } from '@angular/core';
// import { FormControl, FormGroup, Validators } from '@angular/forms';
// import { LoginService } from 'src/app/service/login/login.service';
// import { MyrouteService } from 'src/app/service/myroute.service';
// import { User } from 'src/app/user';


// @Component({
//   selector: 'app-login',
//   templateUrl: './login.component.html',
//   styleUrls: ['./login.component.css']
// })


// export class LoginComponent {
//   user: User[] = [];
//   currentuser: User = { userName: '', password: '' };

//   constructor(private loginservice: LoginService) { }

//   authenticate() {
//     this.loginservice.authenticateUser(this.currentuser).subscribe(
//       response => {
//         if (response && response.token) {
//           const jwtToken = response.token;
//           this.storeToken(jwtToken);
//         } else {
//           console.error('No JWT token found in the response');
//         }
//       }
//     );
//   }

//   storeToken(token: string) {
//     // storing the token (in sessionStorage)
//     sessionStorage.setItem('jwtToken', token); // Storing the token in sessionStorage
//   }
// }

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { LoginService } from 'src/app/service/login/login.service';
import { User } from 'src/app/user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit{

  constructor(private fb: FormBuilder,private loginservice: LoginService,private routeserve : Router) { }
  form: FormGroup = new FormGroup({}); 
  ngOnInit(): void {
    this.form = this.fb.group({
      userName: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.form.valid) {
      const currentuser: User = {
        userName: this.form.get('userName')?.value,
        password: this.form.get('password')?.value
      };
     
      console.log(currentuser);
      this.loginservice.authenticateUser(currentuser).subscribe(
        (response: any) => {
          console.log("The token is ",response.token);
          localStorage.setItem('jwttoken',response.token);

          this.routeserve.navigate(['login/sports']);
        },
        (error: any) => {
          console.log("Error is"+ error);
        alert("New user Registration needed");
        }
      );
      
    }
  }

}
