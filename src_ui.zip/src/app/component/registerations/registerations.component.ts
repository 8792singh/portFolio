import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { RegistrationService } from 'src/app/service/registration/registration.service';
import { Userdetail } from 'src/app/userdetail';

@Component({
  selector: 'app-registerations',
  templateUrl: './registerations.component.html',
  styleUrls: ['./registerations.component.css']
})
export class RegisterationsComponent implements OnInit{
  registrationForm!: FormGroup;

  constructor(private formBuilder: FormBuilder,private registrationService:RegistrationService) { }

  ngOnInit(): void {
    this.registrationForm = this.formBuilder.group({
      userName: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      email: ['', [Validators.required, Validators.email]],
      phoneNumber: ['', Validators.required]
    });
  }

  get formControls() {
    return this.registrationForm.controls;
  }

  onRegister() {
    if (this.registrationForm.invalid) {
      return;
    }
    const user: Userdetail = {
      userName: this.registrationForm.get('userName')?.value,
      password: this.registrationForm.get('password')?.value,
      email: this.registrationForm.get('email')?.value,
      phoneNumber: this.registrationForm.get('phoneNumber')?.value
    };

    this.registrationService.register(user).subscribe(
      (response: any) => {
        
        alert("User Registered successfully");
        

      },
      (error: any) => {
        console.log("Error is"+ error);
      }
    );

  }
}
